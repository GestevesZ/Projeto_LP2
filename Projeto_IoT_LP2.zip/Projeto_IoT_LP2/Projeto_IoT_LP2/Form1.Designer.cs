﻿namespace Projeto_IoT_LP2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btCarregar = new Button();
            btColetarDados = new Button();
            listBox1 = new ListBox();
            cB_Blocos = new ComboBox();
            cB_Salas = new ComboBox();
            lB_Temp = new Label();
            lb_Lumi = new Label();
            lb_Ar = new Label();
            lb_Luz = new Label();
            label1 = new Label();
            bt_Luz = new Button();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // btCarregar
            // 
            btCarregar.Location = new Point(386, 111);
            btCarregar.Name = "btCarregar";
            btCarregar.Size = new Size(103, 29);
            btCarregar.TabIndex = 0;
            btCarregar.Text = "Ligar/Desligar Ar";
            btCarregar.UseVisualStyleBackColor = true;
            btCarregar.Click += btCarregar_Click;
            // 
            // btColetarDados
            // 
            btColetarDados.Location = new Point(75, 258);
            btColetarDados.Name = "btColetarDados";
            btColetarDados.Size = new Size(75, 23);
            btColetarDados.TabIndex = 1;
            btColetarDados.Text = "COLETAR";
            btColetarDados.UseVisualStyleBackColor = true;
            btColetarDados.Click += btColetarDados_Click;
            // 
            // listBox1
            // 
            listBox1.AccessibleRole = AccessibleRole.TitleBar;
            listBox1.BorderStyle = BorderStyle.None;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Items.AddRange(new object[] { "       Histórico de Temperaturas " });
            listBox1.Location = new Point(587, 71);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(177, 90);
            listBox1.TabIndex = 2;
            // 
            // cB_Blocos
            // 
            cB_Blocos.FormattingEnabled = true;
            cB_Blocos.Items.AddRange(new object[] { "A", "B", "C", "D" });
            cB_Blocos.Location = new Point(54, 67);
            cB_Blocos.Name = "cB_Blocos";
            cB_Blocos.Size = new Size(121, 23);
            cB_Blocos.TabIndex = 3;
            // 
            // cB_Salas
            // 
            cB_Salas.FormattingEnabled = true;
            cB_Salas.Items.AddRange(new object[] { "01", "02", "03", "04", "05" });
            cB_Salas.Location = new Point(54, 138);
            cB_Salas.Name = "cB_Salas";
            cB_Salas.Size = new Size(121, 23);
            cB_Salas.TabIndex = 4;
            // 
            // lB_Temp
            // 
            lB_Temp.AutoSize = true;
            lB_Temp.Location = new Point(209, 67);
            lB_Temp.Name = "lB_Temp";
            lB_Temp.Size = new Size(73, 15);
            lB_Temp.TabIndex = 5;
            lB_Temp.Text = "Temperatura";
            lB_Temp.TextAlign = ContentAlignment.MiddleLeft;
            lB_Temp.Visible = false;
            // 
            // lb_Lumi
            // 
            lb_Lumi.AutoSize = true;
            lb_Lumi.Location = new Point(209, 92);
            lb_Lumi.Name = "lb_Lumi";
            lb_Lumi.Size = new Size(82, 15);
            lb_Lumi.TabIndex = 6;
            lb_Lumi.Text = "Luminosidade";
            lb_Lumi.TextAlign = ContentAlignment.MiddleLeft;
            lb_Lumi.Visible = false;
            // 
            // lb_Ar
            // 
            lb_Ar.AutoSize = true;
            lb_Ar.Location = new Point(209, 118);
            lb_Ar.Name = "lb_Ar";
            lb_Ar.Size = new Size(99, 15);
            lb_Ar.TabIndex = 7;
            lb_Ar.Text = "Ar-Condicionado";
            lb_Ar.TextAlign = ContentAlignment.MiddleLeft;
            lb_Ar.Visible = false;
            // 
            // lb_Luz
            // 
            lb_Luz.AutoSize = true;
            lb_Luz.Location = new Point(209, 141);
            lb_Luz.Name = "lb_Luz";
            lb_Luz.Size = new Size(36, 15);
            lb_Luz.TabIndex = 8;
            lb_Luz.Text = "Luzes";
            lb_Luz.TextAlign = ContentAlignment.MiddleLeft;
            lb_Luz.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(209, 43);
            label1.Name = "label1";
            label1.Size = new Size(116, 15);
            label1.TabIndex = 9;
            label1.Text = "Informações da Sala:";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Visible = false;
            // 
            // bt_Luz
            // 
            bt_Luz.Location = new Point(386, 146);
            bt_Luz.Name = "bt_Luz";
            bt_Luz.Size = new Size(75, 23);
            bt_Luz.TabIndex = 10;
            bt_Luz.Text = "Ligar/Desligar Luzes";
            bt_Luz.UseVisualStyleBackColor = true;
            bt_Luz.Click += bt_Luz_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(97, 49);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 11;
            label2.Text = "BLOCO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(97, 120);
            label3.Name = "label3";
            label3.Size = new Size(35, 15);
            label3.TabIndex = 12;
            label3.Text = "SALA";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(bt_Luz);
            Controls.Add(label1);
            Controls.Add(lb_Luz);
            Controls.Add(lb_Ar);
            Controls.Add(lb_Lumi);
            Controls.Add(lB_Temp);
            Controls.Add(cB_Salas);
            Controls.Add(cB_Blocos);
            Controls.Add(listBox1);
            Controls.Add(btColetarDados);
            Controls.Add(btCarregar);
            Name = "Form1";
            Text = "Comunicação Firebase - LP2 - EST/UEA";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCarregar;
        private Button btColetarDados;
        private ListBox listBox1;
        private ComboBox cB_Blocos;
        private ComboBox cB_Salas;
        private Label lB_Temp;
        private Label lb_Lumi;
        private Label lb_Ar;
        private Label lb_Luz;
        private Label label1;
        private Button bt_Luz;
        private Label label2;
        private Label label3;
    }
}
