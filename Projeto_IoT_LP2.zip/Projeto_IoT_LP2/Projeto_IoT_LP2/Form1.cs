using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Firebase.Database;
using Firebase.Database.Query;

namespace Projeto_IoT_LP2
{
    public partial class Form1 : Form
    {
        private const string firebaseUrl = "https://projeto-lp2-1043d-default-rtdb.firebaseio.com/";
        private const string firebaseSecret = "OAfGGrcfwpIL8E9l9txUE3eyfFaDr62ZZL9xZTdA";

        private FirebaseClient firebaseClient;

        //private bool estado_ar = true; // Define o estado do ar-condicionado como ligado (true)
        public Form1()
        {
            InitializeComponent();
            InicializarFirebase();
            listBox1.Visible = false;


        }

        private void InicializarFirebase()
        {
            firebaseClient = new FirebaseClient(
                firebaseUrl,
                new FirebaseOptions
                {
                    AuthTokenAsyncFactory = () => Task.FromResult(firebaseSecret)
                });

            // Chama a fun��o de leitura dos dados

        }
        private async void Ligar_Ar()
        {

            try
            {
                var estado_ar = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Ar-Condicionado")
                        .OnceSingleAsync<bool>();

                estado_ar = !estado_ar;  // Alterna o estado do ar-condicionado


                await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Ar-Condicionado")
                        .PutAsync(estado_ar);


                if (btCarregar_Click != null && estado_ar == true)
                {
                    MessageBox.Show($"Ar-Condicionado da sala {cB_Salas.Text} do Bloco {cB_Blocos.Text} Ligado!");
                }
                else if (btCarregar_Click != null && estado_ar == false)
                {
                    MessageBox.Show($"Ar-Condicionado da sala {cB_Salas.Text} do Bloco {cB_Blocos.Text} Desligado!");
                }
                lb_Ar.Text = estado_ar ? "Ar-Condicionado Ligado" : "Ar-Condicionado Desligado";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao criar blocos: " + ex.Message, "Erro");
            }
        }

        private async void Ligar_Luzes()
        {
            try
            {
                var estado_luz = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Luzes")
                        .OnceSingleAsync<bool>();
                estado_luz = !estado_luz; // Alterna o estado das luzes
                await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Luzes")
                        .PutAsync(estado_luz);
                if (bt_Luz_Click != null && estado_luz == true)
                {
                    MessageBox.Show($"Luzes da sala {cB_Salas.Text} do Bloco {cB_Blocos.Text} Ligadas!");
                }
                else if (bt_Luz_Click != null && estado_luz == false)
                {
                    MessageBox.Show($"Luzes da sala {cB_Salas.Text} do Bloco {cB_Blocos.Text} Desligadas!");
                }
                lb_Luz.Text = estado_luz ? "Luzes Ligadas" : "Luzes Desligadas";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao acessar o Firebase: " + ex.Message, "Erro");
            }
        }
        private async void ColetarDados()
        {
            try
            {
                var temperatura = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Temperatura")
                        .OnceSingleAsync<int>();

                var luminosidade = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Luminosidade")
                        .OnceSingleAsync<int>();

                var estado_ar = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Ar-Condicionado")
                        .OnceSingleAsync<bool>();

                var estado_luz = await firebaseClient
                        .Child("Blocos UEA")
                        .Child(cB_Blocos.Text)
                        .Child(cB_Salas.Text)
                        .Child("Luzes")
                        .OnceSingleAsync<bool>();

                label1.Visible = true;
                lb_Ar.Text = estado_ar ? "Ar-Condicionado Ligado" : "Ar-Condicionado Desligado";
                lb_Luz.Text = estado_luz ? "Luzes Ligadas" : "Luzes Desligadas";
                lb_Lumi.Text = "Luminosidade " + luminosidade.ToString() + " lx";
                lB_Temp.Text = "Temperatura " + temperatura.ToString() + " �C";

                listBox1.Visible = true;
                lb_Luz.Visible = true;
                lb_Ar.Visible = true;
                lB_Temp.Visible = true;
                lb_Lumi.Visible = true;

                listBox1.Items.Add($"Sala {cB_Salas.Text} (Bloco {cB_Blocos.Text}): {temperatura}�C");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao acessar o Firebase: " + ex.Message, "Erro");
            }
        }

        private void btCarregar_Click(object sender, EventArgs e)
        {
            //estado_ar = !estado_ar; // Alterna o estado do ar-condicionado
            Ligar_Ar();
        }

        private void bt_Luz_Click(object sender, EventArgs e)
        {
            Ligar_Luzes();// Implementar a l�gica para ligar/desligar as luzes
        }

        private void btColetarDados_Click(object sender, EventArgs e)
        {
            ColetarDados();
        }

        private void bt_Luz_Click_1(object sender, EventArgs e)
        {
            Ligar_Luzes();
        }
    }
}
